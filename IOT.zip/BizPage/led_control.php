<?php
include('include/connection.php');
// if($_SESSION != null)
// {
//  echo $_SESSION['email'];
// }
if($_SESSION == null)
{
 header('location:login.php');
 die();
}

else{

if(isset($_POST['submit']))
{
  $conn=new mysqli("localhost","root","","test");
  $led_1=$_POST['led1'];
  $led_2=$_POST['led2'];
  $led_3=$_POST['led3'];
  $led_4=$_POST['led4'];
  $email=$_SESSION['email'];
  $conn->query("UPDATE led SET led1='$led_1',led2='$led_2',led3='$led_3',led4='$led_4' where email='$email'");
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Bizpage led_control</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">
  <style type="text/css">
    .led{
      padding-top: 100px;
      padding-bottom: 50px;
    }
  </style>
</head>

<body>
<div style="height: 100px;">
  <?php include 'header.php';?>
</div>



<div class="led" style="height: 300px;">
<form action="" method="POST">
<table >
  <tr>
    <th>LED 1</th>
    <th>LED 2</th>
    <th>LED 3</th>
    <th>LED 4</th>
  </tr>
  <tr>
    <td>
      <input type="radio" name="led1" value="1"> ON<br>
      <input type="radio" name="led1" value="0">OFF<br>
    </td>
    <td>
      <input type="radio" name="led2" value="1"> ON<br>
      <input type="radio" name="led2" value="0">OFF<br>
    </td>
    <td>
      <input type="radio" name="led3" value="1"> ON<br>
      <input type="radio" name="led3" value="0">OFF<br>
    </td>
    <td>
      <input type="radio" name="led4" value="1"> ON<br>
      <input type="radio" name="led4" value="0">OFF<br>
    </td>
    


  </tr>

</table>
<input type="submit" value="Submit" name="submit">
</form></div>
<div style="height: 200px;">
<span> The status of bulbs is : <b>
<?php
$email=$_SESSION['email'];
$r=$conn->query("SELECT led1,led2,led3,led4 FROM led where email= '$email'");
  $v=$r->fetch_assoc();
  echo $v['led1'].$v['led2'].$v['led3'].$v['led4'];
?></b>
<br>
<?php
  $url="http://localhost/BizPage/led_api.php?email=".$email;
   echo "your api link is :".$url           
?>


</span></div>
<div style="text-align: right;">
<a href="program/led_controller.ino" download="led_controller.ino"> Download source code</a>



 </div>
<div style="height: 200px;">
 
  <?php include 'footer.php';?></div>

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- Uncomment below i you want to use a preloader -->
  <!-- <div id="preloader"></div> -->

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>
  <script src="lib/lightbox/js/lightbox.min.js"></script>
  <script src="lib/touchSwipe/jquery.touchSwipe.min.js"></script>
  <!-- Contact Form JavaScript File
  <script src="contactform/contactform.js"></script> -->

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>
</html>
