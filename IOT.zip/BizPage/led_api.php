<?php
include ('include/connection.php');
$email=$_GET['email'];

$r=$conn->query("SELECT led1,led2,led3,led4 FROM led where email= '$email'");
  $v=$r->fetch_assoc();
  echo $v['led1'].$v['led2'].$v['led3'].$v['led4']; 

?>
