<?php
include('include/connection.php');
// if($_SESSION != null)
// {
//  echo $_SESSION['email'];
// }
if($_SESSION == null)
{
 header('location:login.php');
 die();
}
else{

if(isset($_POST['submit']))
{
  $conn=new mysqli("localhost","root","","test");
  $row1=$_POST['row1'];
  $row2=$_POST['row2'];
  $email=$_SESSION['email'];
  $conn->query("UPDATE lcd SET row1='$row1',row2='$row2' where email='$email'");
} 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>BizPage Bootstrap Template</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">


</head>

<body>

  <!--==========================
    Header
  ============================-->
  <div style="height: 150px;">
  <?php include 'header.php';?>
</div>

 
  <div style="height: 400px;">
<form action="" method="POST">
enter row1 number <input type="text" name="row1">
enter row2 number <input type="text" name="row2">

<input type="submit" name="submit"><br><br>
<span> you entered :<br><?php 
  $email=$_SESSION['email'];
  $r=$conn->query("SELECT row1,row2 FROM lcd where email='$email'");
  $v=$r->fetch_assoc();
  echo $v['row1']; ?> <br>
  <?php echo $v['row2']; ?></span><br>
  <?php
  $url="http://localhost/BizPage/lcd_api.php?email=".$email;
   echo "your api link is ".$url           ?>

</form>
</div>

<div style="text-align: right;">
<a href="program/lcd_controller.ino" download="lcd_controller.ino"> Download source code</a>



 </div>
  <!--==========================
    Footer
  ============================-->
  <div style="height: 200px;">

  <?php include 'footer.php';?></div>

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- Uncomment below i you want to use a preloader -->
  <!-- <div id="preloader"></div> -->

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>
  <script src="lib/lightbox/js/lightbox.min.js"></script>
  <script src="lib/touchSwipe/jquery.touchSwipe.min.js"></script>
  <!-- Contact Form JavaScript File
  <script src="contactform/contactform.js"></script> -->

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

</body>
</html>
