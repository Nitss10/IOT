<?php
$email=$_GET['email'];
include('include/connection.php');
$r=$conn->query("SELECT value FROM segment where email='$email'");
  $v=$r->fetch_assoc();
  echo $v['value']; 

?>