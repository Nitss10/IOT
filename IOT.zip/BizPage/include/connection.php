<?php
$conn=new mysqli("localhost","root","","test");
session_start();
?>