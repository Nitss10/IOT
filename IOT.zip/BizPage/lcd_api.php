<?php
include('include/connection.php');
$email=$_GET['email'];
$r=$conn->query("SELECT row1,row2 FROM lcd where email='$email'");
  $v=$r->fetch_assoc();
  echo $v['row1'].",".$v['row2']; 

?>
